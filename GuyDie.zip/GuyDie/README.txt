Thank you for playing GuyDie!
=============================

Project Info:

Name: GuyDie
Created by: Evan Viele @ March 19 2020 - 2:17 AM

=============================
                             
Legal:                       
                             
Please note that there are no licenses on this software. That means you are free to do whatever you want with this software.
                             
=============================

Info:

This software is written in only HTML, making it secure and easy for people to mod.

=============================

IMPORTANT:

This is a work in progress, it is not done yet.

=============================

To Do:

-Add functionality to the game

-Add more gameplay features

-See FutureDoc.txt for more info on what this project needs

=============================

If you have any questions, feel free to contact me at:
vinnyviele6@gmail.com